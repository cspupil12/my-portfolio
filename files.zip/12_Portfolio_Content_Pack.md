# Portfolio Content Pack v2 — Jaspreet (Conor Template Structure)

*Matches the section structure found in Charanjit's template: Hero → About → Projects → Contact, with Experience/Skills/Education added since your content now goes deeper than the template's original scope.*

## 1. Meta / Page Title
`<meta name="description" content="Jaspreet — Founder, PlanBotic | AI Systems, Infrastructure & Automation">`

## 2. Hero Section

**Rotating word (replaces "I'm Developer."):**
Rotate through: `Founder.` / `Builder.` / `Automator.` / `Infrastructure Guy.`

**Sub-line:**
> Hello, I'm **Jaspreet**. I'm a founder and builder based in Jalandhar, Punjab, running **PlanBotic** — building AI agents, automation, and infrastructure for real businesses. Alongside that, I manage server infrastructure and operations at Morado Solutions.

## 3. About Section

**Short bio paragraph:**
> Founder of PlanBotic, where I design AI agents, automation, and secure web infrastructure for clients. I also head infrastructure and HR operations at Morado Solutions. My background spans AI/ML tooling, cloud infrastructure, and game server architecture — a mix that comes from years of hands-on building rather than a single specialization.

## 4. Professional Experience

**Morado Solutions — Manager / Head of HR**
> Overseeing infrastructure services, managing support tickets, maintaining server operations, and handling team coordination — including employee guidelines and administrative operations.

## 5. Technical Skills & Proficiencies

- **Programming & AI Integration:** Python, PyTorch, Generative AI tools, Prompt Engineering, Retrieval-Augmented Generation (RAG) frameworks, Hugging Face models, SQL basics
- **Cloud & Infrastructure:** Google Cloud, Firebase, AWS, VPS networking, SSH configuration, server automation, Pterodactyl panel management
- **Web & App Development:** Three.js, Framer, Vercel, WordPress
- **Game Development & 3D Modeling:** Blender, Blockbench for 3D asset creation; advanced Minecraft server configuration (EssentialsX, LuckPerms, Citizens, Towny, voice chat integration)
- **Data Management:** Complex dataset organization and bifurcation, including large-scale contact dataset handling for research purposes
- **Design & Content Creation:** Graphic design, video editing, AI-driven tools for digital content generation and mockups

## 6. Projects Section
*(Removed: EndWar Server Ecosystem, L99 Clinic Management System — per current scope)*

**Project 1 — SecureStaff**
> Full staff authorization and management system — role-based access control, attendance tracking, leave management, and auto-generated ID cards.

**Project 2 — AutoStock Fleet Manager**
> Multi-company vehicle inventory and fleet management platform with role-based dashboards and live analytics for operational decision-making.

**Project 3 — Cloud & Web Deployments**
> Developing, managing, and hosting cloud deployments for projects including Retrorealm and Nexusnodes, plus personal portfolio sites on Vercel.

**Project 4 — Discord Server Architecture**
> Developing complex Discord servers using custom templates and bots (e.g., Xenon, Sapphire), with secure token management and community organization.

**Project 5 — Advanced Game Server Administration**
> Hosting and managing specialized networks including DonutSMP and Lifesteal servers, focused on backend stability and custom plugin implementations.

## 7. Education & Professional Development

- **Academics:** CBSE Class 12, focus on Computer Science, Mathematics, and English
- **Pursuing BTech in CS & AI** — DAV University, Jalandhar
- **Google Cloud Arcade** — hands-on cloud skill badges and challenges
- **Frontend Designing** — self-driven practice building interfaces and UI systems
- **Other coding bootcamps** — ongoing, outside formal coursework

## 8. Certifications

- **AI Tools & ChatGPT Workshop** — Be10x, completed June 14, 2026 (presentations, data analysis, and code/debug workflows using AI)
  Certificate image: [Be10x_AI_Tools_Workshop.png](certificates/Be10x_AI_Tools_Workshop.png)
- **Gen AI Engineering Mastermind** — Outskill, Certificate of Completion
  Certificate image: [Outskill_GenAI_Mastermind.jpeg](certificates/Outskill_GenAI_Mastermind.jpeg)

## 9. Contact Section

**Fields to keep from template:** Name, Email, Message
**Suggested intro line above the form:**
> Have a project in mind, or want to talk about working together? Reach out — I read everything myself.

**Contact details to add (fill in what you want public):**
- Email: [your PlanBotic email]
- Location: Jalandhar, Punjab, India
- LinkedIn: [your handle]

---

## Notes on adapting the template
- The template's nav only has Home/About/Projects/Contact — with Experience, Skills, Education, and now Certifications added, you'll want a couple new nav anchors (e.g., `#experience`, `#skills`, `#certifications`) or fold them as subsections inside the existing About block, since the Conor template's layout was built for a shorter single-page flow
- Certificate images (Be10x, Outskill) can be displayed as small badge thumbnails in the Certifications section, linking to full-size versions
- Rotating hero word and stats counters are template JS features (`animated.headline.js`) — swap text values only, animation logic stays as-is
- Swap `img/portfolio/*.jpg` placeholders with real screenshots once available for each project
- Personal ambitions/extracurriculars (armed forces prep, DIY/craft, stand-up, YouTube) from Gemini's draft were left out of this version — let me know if you want a "Beyond Work" section added; worth deciding deliberately since it changes the tone from strictly professional to more personal
